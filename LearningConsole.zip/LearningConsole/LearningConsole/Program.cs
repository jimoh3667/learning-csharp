﻿// See https://aka.ms/new-console-template for more information

using LearningConsole.ClassFolders;

//var a = "b";
//Console.WriteLine(a);

//Jumoke myobject = new();

//myobject.MyBioGraphy();

//Jumoke.GetMyBioGraphy();

//LearningArray.ShowHowArraysWork();


var genericClasses = new GenericClasses();

genericClasses.ShowCollectionDiff();